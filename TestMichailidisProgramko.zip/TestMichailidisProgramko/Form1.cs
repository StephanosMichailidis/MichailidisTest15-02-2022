﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TestMichailidisProgramko
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Pen green = new Pen(Color.Green);
        Pen red = new Pen(Color.Red);
        Pen yellow = new Pen(Color.Yellow);
        System.Drawing.SolidBrush fillGreen = new System.Drawing.SolidBrush(Color.Green);
        System.Drawing.SolidBrush fillRed = new System.Drawing.SolidBrush(Color.Red);
        Rectangle circle = new Rectangle(80+70, 80, 80, 80);
        Rectangle circle1 = new Rectangle(80, 80, 80, 80);
        Rectangle circle2 = new Rectangle(80+140, 80, 80, 80);
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawEllipse(green, circle);
            Graphics c = e.Graphics;
            c.DrawEllipse(red, circle1);
            Graphics b = e.Graphics;
            b.DrawEllipse(yellow,circle2);

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        
    }
}
